const {
  ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder,
  ModalBuilder, TextInputBuilder, TextInputStyle, ChannelType, PermissionFlagsBits: P,
} = require('discord.js');
const cfg = require('./config');

const embed = () => new EmbedBuilder().setColor(cfg.color).setTimestamp().setFooter({ text: cfg.botName });

const isStaff = (m) =>
  m.permissions.has(P.Administrator) || cfg.staffRoles.some((r) => m.roles.cache.has(r));

function parseTopic(ch) {
  const t = (ch?.topic || '').split(':');
  if (t[0] !== 'ticket') return null;
  return { ownerId: t[1], claimerId: t[2] || '0', type: t.slice(3).join(':') };
}
const buildTopic = (ownerId, claimerId, type) => `ticket:${ownerId}:${claimerId}:${type}`;

const slug = (s) =>
  s.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9\u00C0-\u024F_-]/g, '');

function panelPayload() {
  const e = embed()
    .setTitle(cfg.panelTitle)
    .setDescription(
      cfg.panelDescription + '\n\n' +
      cfg.ticketTypes.map((t) => `${t.emoji || '🎫'} **${t.label}** — ${t.desc}`).join('\n')
    );
  const menu = new StringSelectMenuBuilder()
    .setCustomId('ticket_open')
    .setPlaceholder('📂 Seleziona una categoria...')
    .addOptions(
      cfg.ticketTypes.map((t, i) => ({
        label: t.label,
        value: String(i),
        description: t.desc.slice(0, 100),
        emoji: t.emoji,
      }))
    );
  return { embeds: [e], components: [new ActionRowBuilder().addComponents(menu)] };
}

async function ensurePanel(client) {
  try {
    const ch = await client.channels.fetch(cfg.panelChannelId);
    const msgs = await ch.messages.fetch({ limit: 50 });
    const existing = msgs.find(
      (m) => m.author.id === client.user.id &&
        m.components.some((r) => r.components.some((c) => c.customId === 'ticket_open'))
    );
    if (existing) await existing.edit(panelPayload());
    else await ch.send(panelPayload());
    console.log('✅ Pannello ticket pronto');
  } catch (err) {
    console.error('❌ Impossibile inviare il pannello ticket:', err.message);
  }
}

function staffCallModal() {
  return new ModalBuilder()
    .setCustomId('ssu_staff_modal')
    .setTitle('Chiama lo staff')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('roblox')
          .setLabel('Nome Roblox')
          .setStyle(TextInputStyle.Short)
          .setMaxLength(50)
          .setRequired(true)
      )
    );
}

function reasonModal(typeIndex) {
  return new ModalBuilder()
    .setCustomId(`ticket_modal:${typeIndex}`)
    .setTitle(`Ticket - ${cfg.ticketTypes[typeIndex].label}`.slice(0, 45))
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('reason')
          .setLabel('Spiega cosa desideri')
          .setStyle(TextInputStyle.Paragraph)
          .setMinLength(10)
          .setMaxLength(1000)
          .setRequired(true)
      )
    );
}

function closeModal() {
  return new ModalBuilder()
    .setCustomId('ticket_close_modal')
    .setTitle('Chiusura ticket')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('reason')
          .setLabel('Motivo della chiusura')
          .setStyle(TextInputStyle.Paragraph)
          .setMaxLength(500)
          .setRequired(true)
      )
    );
}

async function createTicket(interaction, typeIndex, reason) {
  const { guild, user, client } = interaction;
  const type = cfg.ticketTypes[typeIndex];
  if (!type) return { error: 'Categoria non valida.' };

  const existing = guild.channels.cache.find(
    (c) => c.parentId === cfg.categoryId && parseTopic(c)?.ownerId === user.id
  );
  if (existing) return { error: `Hai già un ticket aperto: ${existing}` };

  const staffPerms = [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles];
  const channel = await guild.channels.create({
    name: `🎫${slug(type.label)}-${user.username}`,
    type: ChannelType.GuildText,
    parent: cfg.categoryId,
    topic: buildTopic(user.id, '0', type.label),
    permissionOverwrites: [
      { id: guild.id, deny: [P.ViewChannel] },
      { id: user.id, allow: staffPerms },
      ...cfg.staffRoles.map((id) => ({ id, allow: staffPerms })),
      {
        id: client.user.id,
        allow: [P.ViewChannel, P.SendMessages, P.ManageChannels, P.ManageRoles, P.EmbedLinks, P.ReadMessageHistory],
      },
    ],
  });

  const e = embed()
    .setTitle(`🎫 Ticket ${type.label}`)
    .setDescription(`Benvenuto ${user}! Un membro dello staff ti assisterà a breve.`)
    .addFields(
      { name: '📂 Categoria', value: `${type.emoji || ''} ${type.label}`, inline: true },
      { name: '👤 Aperto da', value: `${user}`, inline: true },
      { name: '📝 Richiesta', value: reason.slice(0, 1000) }
    )
    .setThumbnail(user.displayAvatarURL());

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_claim').setLabel('Reclama').setEmoji('🙋').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Chiudi').setEmoji('🔒').setStyle(ButtonStyle.Danger)
  );

  await channel.send({
    content: `${user} ${cfg.staffRoles.map((r) => `<@&${r}>`).join(' ')}`,
    embeds: [e],
    components: [row],
    allowedMentions: { users: [user.id], roles: cfg.staffRoles },
  });
  return { channel };
}

function check(channel, member, { claimOwnerOnly = true } = {}) {
  const info = parseTopic(channel);
  if (!info) return { error: 'Questo comando si può usare solo dentro un ticket.' };
  if (!isStaff(member)) return { error: 'Solo lo staff può farlo.' };
  if (
    claimOwnerOnly && info.claimerId !== '0' && info.claimerId !== member.id &&
    !member.permissions.has(P.Administrator)
  ) {
    return { error: `Il ticket è stato reclamato da <@${info.claimerId}>, solo lui può gestirlo.` };
  }
  return { info };
}

async function claim(channel, member) {
  const { info, error } = check(channel, member, { claimOwnerOnly: false });
  if (error) return { error };
  if (info.claimerId !== '0') return { error: `Ticket già reclamato da <@${info.claimerId}>.` };

  await channel.permissionOverwrites.edit(member.id, {
    ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true,
  });
  for (const id of cfg.staffRoles) {
    await channel.permissionOverwrites.edit(id, {
      ViewChannel: true, SendMessages: false, ReadMessageHistory: true, AddReactions: false,
    });
  }
  await channel.setTopic(buildTopic(info.ownerId, member.id, info.type));

  await channel.send({
    content: `<@${info.ownerId}>`,
    embeds: [embed().setTitle('✅ Ticket reclamato').setDescription(`Ticket reclamato da: ${member}`)],
    allowedMentions: { users: [info.ownerId, member.id] },
  });
  return { ok: true };
}

async function close(channel, member, reason) {
  const { info, error } = check(channel, member);
  if (error) return { error };

  await channel.send({
    content: `<@${info.ownerId}>`,
    embeds: [
      embed()
        .setTitle('🔒 Ticket in chiusura')
        .addFields(
          { name: 'Chiuso da', value: `${member}`, inline: true },
          { name: 'Motivo', value: reason.slice(0, 1000) }
        )
        .setFooter({ text: `Il canale verrà eliminato tra 5 secondi • ${cfg.botName}` }),
    ],
    allowedMentions: { users: [info.ownerId] },
  });
  setTimeout(() => channel.delete('Ticket chiuso').catch(console.error), 5000);
  return { ok: true };
}

async function addUser(channel, member, user) {
  const { error } = check(channel, member);
  if (error) return { error };
  await channel.permissionOverwrites.edit(user.id, {
    ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true,
  });
  return { ok: true };
}

async function removeUser(channel, member, user) {
  const { info, error } = check(channel, member);
  if (error) return { error };
  if (user.id === info.ownerId) return { error: 'Non puoi rimuovere chi ha aperto il ticket.' };
  await channel.permissionOverwrites.delete(user.id);
  return { ok: true };
}

async function rename(channel, member, name) {
  const { error } = check(channel, member);
  if (error) return { error };
  const clean = slug(name).slice(0, 80);
  if (!clean) return { error: 'Nome non valido.' };
  await channel.setName(`🎫${clean}`);
  return { ok: true };
}

module.exports = {
  embed, isStaff, check, parseTopic, panelPayload, ensurePanel, staffCallModal, reasonModal, closeModal,
  createTicket, claim, close, addUser, removeUser, rename,
};
