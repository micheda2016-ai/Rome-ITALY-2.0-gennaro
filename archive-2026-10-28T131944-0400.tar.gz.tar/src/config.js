require('dotenv').config();

const list = (v) => (v || '').split(',').map((s) => s.trim()).filter(Boolean);
const text = (v, d = '') => (v ?? d).replace(/\\n/g, '\n');

const required = ['TOKEN', 'CLIENT_ID', 'GUILD_ID', 'TICKET_CATEGORY_ID', 'STAFF_ROLE_IDS'];
for (const k of required) {
  if (!process.env[k] || process.env[k].startsWith('INSERISCI')) {
    console.error(`[CONFIG] Manca la variabile ${k} nel file .env`);
    process.exit(1);
  }
}

const ticketTypes = (process.env.TICKET_TYPES || '')
  .split(';')
  .map((s) => s.trim())
  .filter(Boolean)
  .map((s) => {
    const [label, emoji, desc] = s.split('|').map((x) => (x || '').trim());
    return { label, emoji: emoji || undefined, desc: desc || 'Apri un ticket' };
  })
  .slice(0, 25);

module.exports = {
  token: process.env.TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID,
  color: process.env.EMBED_COLOR || '#009246',
  serverName: process.env.SERVER_NAME || 'ROME, ITALY',
  botName: process.env.BOT_NAME || 'ROME ITALY 🇮🇹 BOT',

  panelChannelId: process.env.TICKET_PANEL_CHANNEL_ID,
  categoryId: process.env.TICKET_CATEGORY_ID,
  staffRoles: list(process.env.STAFF_ROLE_IDS),
  panelTitle: process.env.PANEL_TITLE || '🎫 Centro Assistenza',
  panelDescription: text(process.env.PANEL_DESCRIPTION, 'Seleziona una categoria dal menu.'),
  ticketTypes,

  partnershipPingId: process.env.PARTNERSHIP_PING_ID,
  partnershipChannelId: process.env.PARTNERSHIP_CHANNEL_ID,

  supportChannelId: process.env.SUPPORT_CHANNEL_ID,
  supportPingId: process.env.SUPPORT_PING_ID,

  ssuRoles: list(process.env.SSU_ROLE_IDS),
  ssuChannelId: process.env.SSU_CHANNEL_ID,
  ssuPing: process.env.SSU_PING || '',
  ssuMessage: text(process.env.SSU_MESSAGE, 'Il server è ora **APERTO**!'),
  ssdMessage: text(process.env.SSD_MESSAGE, 'Il server è ora **CHIUSO**.'),

  welcomeChannelId: process.env.WELCOME_CHANNEL_ID,
  welcomeTitle: process.env.WELCOME_TITLE || '👋 Benvenuto!',
  welcomeMessage: text(process.env.WELCOME_MESSAGE, 'Benvenuto {user} in {server}!'),
};
