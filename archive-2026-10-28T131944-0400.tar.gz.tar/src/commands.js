const { SlashCommandBuilder, MessageFlags, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const cfg = require('./config');
const t = require('./ticket');

const eph = { flags: MessageFlags.Ephemeral };
const reply = (i, msg) => i.reply({ content: msg, ...eph });

const commands = [
  {
    data: new SlashCommandBuilder().setName('reclama').setDescription('Reclama questo ticket'),
    async run(i) {
      const r = await t.claim(i.channel, i.member);
      return reply(i, r.error ? `❌ ${r.error}` : '✅ Hai reclamato il ticket.');
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName('chiudi').setDescription('Chiudi questo ticket')
      .addStringOption((o) => o.setName('motivo').setDescription('Motivo della chiusura').setRequired(true)),
    async run(i) {
      const r = await t.close(i.channel, i.member, i.options.getString('motivo'));
      return reply(i, r.error ? `❌ ${r.error}` : '🔒 Chiusura in corso...');
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName('aggiungi').setDescription('Aggiungi un utente al ticket')
      .addUserOption((o) => o.setName('utente').setDescription('Utente da aggiungere').setRequired(true)),
    async run(i) {
      const u = i.options.getUser('utente');
      const r = await t.addUser(i.channel, i.member, u);
      return i.reply(r.error ? { content: `❌ ${r.error}`, ...eph } : { content: `✅ ${u} è stato aggiunto al ticket.`, allowedMentions: { users: [u.id] } });
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName('rimuovi').setDescription('Rimuovi un utente dal ticket')
      .addUserOption((o) => o.setName('utente').setDescription('Utente da rimuovere').setRequired(true)),
    async run(i) {
      const u = i.options.getUser('utente');
      const r = await t.removeUser(i.channel, i.member, u);
      return reply(i, r.error ? `❌ ${r.error}` : `✅ ${u.username} è stato rimosso dal ticket.`);
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName('rinomina').setDescription('Rinomina il ticket')
      .addStringOption((o) => o.setName('nome').setDescription('Nuovo nome').setRequired(true)),
    async run(i) {
      const r = await t.rename(i.channel, i.member, i.options.getString('nome'));
      return reply(i, r.error ? `❌ ${r.error}` : '✅ Ticket rinominato.');
    },
  },
  {
    data: new SlashCommandBuilder()
      .setName('partnership').setDescription('Invia una partnership (staff)')
      .addStringOption((o) => o.setName('server').setDescription('Nome del server partner').setRequired(true))
      .addStringOption((o) => o.setName('descrizione').setDescription('Descrizione del server partner').setRequired(true))
      .addStringOption((o) => o.setName('invito').setDescription('Link di invito').setRequired(true)),
    async run(i) {
      if (!t.isStaff(i.member)) return reply(i, '❌ Solo lo staff può usare questo comando.');
      const e = t.embed()
        .setTitle(`🤝 Partnership - ${i.options.getString('server')}`)
        .setDescription(i.options.getString('descrizione'))
        .addFields(
          { name: '🔗 Invito', value: i.options.getString('invito') },
          { name: '👤 Gestita da', value: `${i.user}` }
        );
      const ch = await i.guild.channels.fetch(cfg.partnershipChannelId).catch(() => null);
      if (!ch) return reply(i, '❌ Canale partner non trovato, controlla PARTNERSHIP_CHANNEL_ID.');
      await ch.send({
        content: `<@&${cfg.partnershipPingId}>`,
        embeds: [e],
        allowedMentions: { roles: [cfg.partnershipPingId] },
      });
      return reply(i, `✅ Partnership inviata in ${ch}.`);
    },
  },
  ...['ssu', 'ssd'].map((name) => {
    const open = name === 'ssu';
    const builder = new SlashCommandBuilder()
      .setName(name)
      .setDescription(open ? "Annuncia l'apertura del server (SSU)" : 'Annuncia la chiusura del server (SSD)');
    if (open) {
      builder
        .addStringOption((o) => o.setName('codice').setDescription('Codice del server').setRequired(true))
        .addIntegerOption((o) => o.setName('staff').setDescription('Staff in servizio').setMinValue(0));
    }
    return {
      data: builder,
      async run(i) {
        if (!cfg.ssuRoles.some((r) => i.member.roles.cache.has(r))) {
          return reply(i, '❌ Non hai la chiave SSU/SSD.');
        }
        const ch = await i.guild.channels.fetch(cfg.ssuChannelId).catch(() => null);
        if (!ch) return reply(i, '❌ Canale SSU non trovato, controlla SSU_CHANNEL_ID.');

        const now = Math.floor(Date.now() / 1000);
        const label = open ? 'SSU' : 'SSD';
        const e = t.embed()
          .setColor(open ? '#2ECC71' : '#E74C3C')
          .setTitle(`${open ? '🟢' : '🔴'} ${cfg.serverName} • SERVER ${label}`)
          .setDescription(open ? cfg.ssuMessage : cfg.ssdMessage)
          .setFooter({ text: `${cfg.botName} • Server ${label} • Aggiornato` });

        if (open) {
          e.addFields(
            { name: '📌 Status:', value: '✅ `Online`', inline: true },
            { name: '🔑 Codice:', value: `\`${i.options.getString('codice')}\``, inline: true },
            { name: '👥 Giocatori in game:', value: '⚠️ non disponibile al momento' },
            { name: '🛡️ Staff in servizio:', value: String(i.options.getInteger('staff') ?? 0), inline: true },
            { name: '⏱️ Aperto:', value: `<t:${now}:R>`, inline: true },
            { name: '👑 Gestito da:', value: `${i.user}` }
          );
        } else {
          e.addFields(
            { name: '📌 Status:', value: '⛔ `Offline`', inline: true },
            { name: '⏱️ Chiuso:', value: `<t:${now}:R>`, inline: true },
            { name: '👑 Gestito da:', value: `${i.user}` }
          );
        }

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('ssu_call_staff').setLabel('Chiama lo staff').setEmoji('🆘').setStyle(ButtonStyle.Primary)
        );

        await ch.send({
          content: open ? cfg.ssuPing || undefined : undefined,
          embeds: [e],
          components: open ? [row] : [],
          allowedMentions: { parse: ['everyone', 'roles'] },
        });
        return reply(i, `✅ ${label} inviato in ${ch}.`);
      },
    };
  }),
];

module.exports = commands;
