const { Client, GatewayIntentBits, Events, REST, Routes, MessageFlags } = require('discord.js');
const cfg = require('./src/config');
const t = require('./src/ticket');
const commands = require('./src/commands');

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers],
});
const map = new Map(commands.map((c) => [c.data.name, c]));
const eph = { flags: MessageFlags.Ephemeral };

client.once(Events.ClientReady, async (c) => {
  console.log(`✅ Online come ${c.user.tag}`);
  const guild = await c.guilds.fetch(cfg.guildId).catch(() => null);
  if (!guild) {
    console.error(`❌ GUILD_ID non valido o il bot non è nel server ${cfg.guildId}.`);
    const mine = await c.guilds.fetch();
    console.error('Server in cui si trova il bot:');
    mine.forEach((g) => console.error(` - ${g.name}: ${g.id}`));
    if (!mine.size) console.error(' (nessuno: invita il bot con gli scope bot + applications.commands)');
    process.exit(1);
  }
  await guild.channels.fetch();
  const rest = new REST().setToken(cfg.token);
  await rest.put(Routes.applicationGuildCommands(cfg.clientId, cfg.guildId), {
    body: commands.map((x) => x.data.toJSON()),
  });
  console.log(`✅ ${commands.length} comandi registrati`);
  await t.ensurePanel(c);
});

client.on(Events.GuildMemberAdd, async (member) => {
  if (!cfg.welcomeChannelId) return;
  const ch = await member.guild.channels.fetch(cfg.welcomeChannelId).catch(() => null);
  if (!ch) return;
  const desc = cfg.welcomeMessage
    .replaceAll('{user}', `${member}`)
    .replaceAll('{server}', member.guild.name)
    .replaceAll('{count}', String(member.guild.memberCount));
  await ch.send({
    content: `${member}`,
    embeds: [
      t.embed().setTitle(cfg.welcomeTitle).setDescription(desc)
        .setThumbnail(member.user.displayAvatarURL({ size: 256 })),
    ],
    allowedMentions: { users: [member.id] },
  });
});

client.on(Events.InteractionCreate, async (i) => {
  try {
    if (i.isChatInputCommand()) return await map.get(i.commandName)?.run(i);

    if (i.isButton() && i.customId === 'ssu_call_staff') return await i.showModal(t.staffCallModal());

    if (i.isModalSubmit() && i.customId === 'ssu_staff_modal') {
      await i.deferReply(eph);
      const ch = await i.guild.channels.fetch(cfg.supportChannelId).catch(() => null);
      if (!ch) return i.editReply('❌ Canale supporto non trovato.');
      const name = i.fields.getTextInputValue('roblox');
      await ch.send({
        content: `<@&${cfg.supportPingId}> **${name}** ha bisogno di supporto`,
        allowedMentions: { roles: [cfg.supportPingId] },
      });
      return i.editReply('✅ Lo staff è stato avvisato, attendi in game.');
    }

    if (i.isStringSelectMenu() && i.customId === 'ticket_open') {
      await i.showModal(t.reasonModal(Number(i.values[0])));
      i.message.edit({ components: i.message.components }).catch(() => {});
      return;
    }

    if (i.isModalSubmit() && i.customId.startsWith('ticket_modal:')) {
      await i.deferReply(eph);
      const r = await t.createTicket(i, Number(i.customId.split(':')[1]), i.fields.getTextInputValue('reason'));
      return i.editReply(r.error ? `❌ ${r.error}` : `✅ Ticket creato: ${r.channel}`);
    }

    if (i.isModalSubmit() && i.customId === 'ticket_close_modal') {
      await i.deferReply(eph);
      const r = await t.close(i.channel, i.member, i.fields.getTextInputValue('reason'));
      return i.editReply(r.error ? `❌ ${r.error}` : '🔒 Chiusura in corso...');
    }

    if (i.isButton() && i.customId === 'ticket_claim') {
      await i.deferReply(eph);
      const r = await t.claim(i.channel, i.member);
      return i.editReply(r.error ? `❌ ${r.error}` : '✅ Hai reclamato il ticket.');
    }

    if (i.isButton() && i.customId === 'ticket_close') {
      const { error } = t.check(i.channel, i.member);
      if (error) return i.reply({ content: `❌ ${error}`, ...eph });
      return i.showModal(t.closeModal());
    }
  } catch (err) {
    console.error(err);
    const text = err.code === 50013
      ? '❌ Il bot non ha i permessi necessari (Gestisci canali, Gestisci ruoli, Invia messaggi). Controlla il suo ruolo e i permessi di canale/categoria.'
      : '❌ Si è verificato un errore.';
    const msg = { content: text, ...eph };
    if (i.deferred || i.replied) i.editReply(msg).catch(() => {});
    else i.reply(msg).catch(() => {});
  }
});

process.on('unhandledRejection', (e) => console.error(e));
client.login(cfg.token);
